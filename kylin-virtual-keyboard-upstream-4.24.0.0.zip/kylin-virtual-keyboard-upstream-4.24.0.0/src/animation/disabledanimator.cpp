/*
 * Copyright (c) KylinSoft Co., Ltd. 2023.All rights reserved.
 *
 * This program is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program. If not, see <https://www.gnu.org/licenses/>.
 */

#include "animation/disabledanimator.h"

DisabledAnimator::DisabledAnimator() : Animator() {}

void DisabledAnimator::playShowAnimation(QWindow *view,
                                         const QRect &endGeometry) {
    view->setGeometry(endGeometry);
    view->show();
    emit animationFinished();
}

void DisabledAnimator::playHideAnimation(QWindow *view,
                                         const QRect &endGeometry) {
    Q_UNUSED(view);
    Q_UNUSED(endGeometry);
    emit animationFinished();
}

void DisabledAnimator::playFlipAnimation(QWindow *view,
                                         const QRect &endGeometry) {
    view->setGeometry(endGeometry);
    emit animationFinished();
}
