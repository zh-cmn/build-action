<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>FloatButton</name>
    <message>
        <location filename="../src/virtualkeyboardentry/floatbutton.cpp" line="142"/>
        <source>Click to show virtual keyboard</source>
        <translation>Click to show virtual keyboard</translation>
    </message>
</context>
<context>
    <name>HideButton</name>
    <message>
        <location filename="../qml/HideButton.qml" line="38"/>
        <source>close</source>
        <translation>close</translation>
    </message>
</context>
<context>
    <name>PlacementModeButton</name>
    <message>
        <location filename="../qml/PlacementModeButton.qml" line="40"/>
        <location filename="../qml/PlacementModeButton.qml" line="67"/>
        <source>Floating Mode</source>
        <translation>Floating Mode</translation>
    </message>
    <message>
        <location filename="../qml/PlacementModeButton.qml" line="78"/>
        <source>Docking Mode</source>
        <translation>Docking Mode</translation>
    </message>
</context>
<context>
    <name>VirtualKeyboardEntryManager</name>
    <message>
        <location filename="../src/virtualkeyboardentry/virtualkeyboardentrymanager.cpp" line="83"/>
        <source>Disable the float button</source>
        <translation>Disable the float ball</translation>
    </message>
    <message>
        <location filename="../src/virtualkeyboardentry/virtualkeyboardentrymanager.cpp" line="93"/>
        <source>Enable the float button</source>
        <translation>Enable the float ball</translation>
    </message>
</context>
<context>
    <name>VirtualKeyboardTrayIcon</name>
    <message>
        <location filename="../src/virtualkeyboardentry/virtualkeyboardtrayicon.cpp" line="41"/>
        <source>Virtual Keyboard</source>
        <translation>Virtual Keyboard</translation>
    </message>
</context>
</TS>
